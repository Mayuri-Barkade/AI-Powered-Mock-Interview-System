import React, { createContext, useContext, useState, useCallback } from "react";

interface User {
  id: string;
  username: string;
  email: string;
}

interface AuthContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<void>;
  signup: (username: string, email: string, password: string) => Promise<void>;
  logout: () => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(() => {
    const stored = localStorage.getItem("interview_user");
    return stored ? JSON.parse(stored) : null;
  });

  const login = useCallback(async (email: string, _password: string) => {
    // In production, this would call Django API: POST /api/accounts/login/
    const mockUser: User = { id: "1", username: email.split("@")[0], email };
    setUser(mockUser);
    localStorage.setItem("interview_user", JSON.stringify(mockUser));
  }, []);

  const signup = useCallback(async (username: string, email: string, _password: string) => {
    // In production: POST /api/accounts/register/
    const mockUser: User = { id: "1", username, email };
    setUser(mockUser);
    localStorage.setItem("interview_user", JSON.stringify(mockUser));
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    localStorage.removeItem("interview_user");
  }, []);

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, signup, logout }}>
      {children}
    </AuthContext.Provider>
  );
};
