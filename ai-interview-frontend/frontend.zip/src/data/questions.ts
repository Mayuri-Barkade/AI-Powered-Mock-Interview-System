export interface InterviewQuestion {
  id: number;
  role: string;
  category: string;
  question: string;
  difficulty: "easy" | "medium" | "hard";
  expectedTopics: string[];
}

export interface InterviewResponse {
  questionId: number;
  answer: string;
  score: number;
  feedback: {
    relevance: number;
    technicalAccuracy: number;
    communicationClarity: number;
    overallScore: number;
    strengths: string[];
    improvements: string[];
    suggestions: string[];
  };
}

export interface InterviewSession {
  id: string;
  role: string;
  date: string;
  responses: InterviewResponse[];
  averageScore: number;
  status: "in_progress" | "completed";
}

export const ROLES = [
  { id: "software_developer", label: "Software Developer", icon: "💻", color: "from-primary to-primary/70" },
  { id: "data_analyst", label: "Data Analyst", icon: "📊", color: "from-info to-info/70" },
  { id: "product_manager", label: "Product Manager", icon: "📋", color: "from-accent to-accent/70" },
  { id: "devops_engineer", label: "DevOps Engineer", icon: "⚙️", color: "from-warning to-warning/70" },
  { id: "ml_engineer", label: "ML Engineer", icon: "🤖", color: "from-success to-success/70" },
  { id: "frontend_developer", label: "Frontend Developer", icon: "🎨", color: "from-destructive to-destructive/70" },
] as const;

export const QUESTIONS_DB: InterviewQuestion[] = [
  // Software Developer
  { id: 1, role: "software_developer", category: "DSA", question: "Explain the difference between a stack and a queue. When would you use each?", difficulty: "easy", expectedTopics: ["LIFO", "FIFO", "use cases", "data structure"] },
  { id: 2, role: "software_developer", category: "OOP", question: "What are the four pillars of Object-Oriented Programming? Explain with examples.", difficulty: "medium", expectedTopics: ["encapsulation", "inheritance", "polymorphism", "abstraction"] },
  { id: 3, role: "software_developer", category: "System Design", question: "How would you design a URL shortener like bit.ly?", difficulty: "hard", expectedTopics: ["hashing", "database", "redirection", "scalability", "analytics"] },
  { id: 4, role: "software_developer", category: "Web", question: "Explain the difference between REST and GraphQL APIs.", difficulty: "medium", expectedTopics: ["endpoints", "query", "over-fetching", "schema", "flexibility"] },
  { id: 5, role: "software_developer", category: "Database", question: "What is database normalization? Explain first, second, and third normal forms.", difficulty: "medium", expectedTopics: ["1NF", "2NF", "3NF", "redundancy", "functional dependency"] },
  // Data Analyst
  { id: 6, role: "data_analyst", category: "SQL", question: "Explain the difference between INNER JOIN, LEFT JOIN, and FULL OUTER JOIN with examples.", difficulty: "easy", expectedTopics: ["join types", "matching rows", "null values", "Venn diagram"] },
  { id: 7, role: "data_analyst", category: "Statistics", question: "What is the Central Limit Theorem and why is it important in data analysis?", difficulty: "medium", expectedTopics: ["normal distribution", "sample size", "mean", "standard deviation"] },
  { id: 8, role: "data_analyst", category: "Visualization", question: "How would you choose the right chart type for presenting data? Give examples.", difficulty: "easy", expectedTopics: ["bar chart", "line chart", "scatter plot", "pie chart", "audience"] },
  // Product Manager
  { id: 9, role: "product_manager", category: "Strategy", question: "How would you prioritize features for a new product release?", difficulty: "medium", expectedTopics: ["MoSCoW", "RICE", "user impact", "business value", "effort"] },
  { id: 10, role: "product_manager", category: "Metrics", question: "What KPIs would you track for a mobile app launch?", difficulty: "medium", expectedTopics: ["DAU", "retention", "conversion", "NPS", "churn rate"] },
  // DevOps
  { id: 11, role: "devops_engineer", category: "CI/CD", question: "Explain a CI/CD pipeline and its stages.", difficulty: "medium", expectedTopics: ["build", "test", "deploy", "automation", "integration"] },
  { id: 12, role: "devops_engineer", category: "Containers", question: "What is Docker and how does it differ from virtual machines?", difficulty: "easy", expectedTopics: ["containerization", "images", "lightweight", "isolation", "kernel"] },
  // ML Engineer
  { id: 13, role: "ml_engineer", category: "Fundamentals", question: "Explain the bias-variance tradeoff in machine learning.", difficulty: "medium", expectedTopics: ["underfitting", "overfitting", "generalization", "model complexity"] },
  { id: 14, role: "ml_engineer", category: "Deep Learning", question: "What is a convolutional neural network and where is it used?", difficulty: "medium", expectedTopics: ["convolution", "pooling", "feature extraction", "image recognition"] },
  // Frontend Developer
  { id: 15, role: "frontend_developer", category: "React", question: "Explain the virtual DOM and how React uses it for efficient rendering.", difficulty: "medium", expectedTopics: ["diffing", "reconciliation", "performance", "real DOM", "batch updates"] },
  { id: 16, role: "frontend_developer", category: "CSS", question: "What is the difference between Flexbox and CSS Grid? When would you use each?", difficulty: "easy", expectedTopics: ["one-dimensional", "two-dimensional", "layout", "alignment", "responsive"] },
];
