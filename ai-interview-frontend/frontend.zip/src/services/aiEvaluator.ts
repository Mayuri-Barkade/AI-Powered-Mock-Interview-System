import { InterviewResponse, InterviewQuestion } from "@/data/questions";

// Simulates AI evaluation — in production, this calls Django: POST /api/ai_feedback/evaluate/
export async function evaluateAnswer(
  question: InterviewQuestion,
  answer: string
): Promise<InterviewResponse["feedback"]> {
  // Simulate processing delay
  await new Promise((r) => setTimeout(r, 1500));

  const words = answer.toLowerCase().split(/\s+/);
  const wordCount = words.length;

  // Check how many expected topics are mentioned
  const topicMatches = question.expectedTopics.filter((topic) =>
    words.some((w) => w.includes(topic.toLowerCase()) || topic.toLowerCase().includes(w))
  );
  const topicCoverage = topicMatches.length / question.expectedTopics.length;

  // Relevance: based on topic coverage and answer length
  const relevance = Math.min(100, Math.round(topicCoverage * 70 + Math.min(wordCount / 2, 30)));

  // Technical accuracy: based on topic matches
  const technicalAccuracy = Math.min(100, Math.round(topicCoverage * 80 + (wordCount > 20 ? 20 : wordCount)));

  // Communication clarity: based on sentence structure
  const sentences = answer.split(/[.!?]+/).filter(Boolean);
  const avgSentenceLength = wordCount / Math.max(sentences.length, 1);
  const communicationClarity = Math.min(
    100,
    Math.round(
      (avgSentenceLength > 5 && avgSentenceLength < 25 ? 70 : 40) +
      (wordCount > 30 ? 20 : wordCount * 0.6) +
      (sentences.length > 2 ? 10 : 0)
    )
  );

  const overallScore = Math.round((relevance + technicalAccuracy + communicationClarity) / 3);

  const strengths: string[] = [];
  const improvements: string[] = [];
  const suggestions: string[] = [];

  if (topicCoverage > 0.6) strengths.push("Good coverage of key concepts");
  if (wordCount > 40) strengths.push("Detailed and comprehensive response");
  if (sentences.length > 2) strengths.push("Well-structured answer with multiple points");
  if (relevance > 70) strengths.push("Answer is highly relevant to the question");

  if (topicCoverage < 0.4) improvements.push("Cover more key topics related to the question");
  if (wordCount < 20) improvements.push("Provide a more detailed answer");
  if (sentences.length < 2) improvements.push("Structure your answer into clear points");
  if (communicationClarity < 60) improvements.push("Improve clarity by using shorter, focused sentences");

  const missingTopics = question.expectedTopics.filter(
    (t) => !words.some((w) => w.includes(t.toLowerCase()) || t.toLowerCase().includes(w))
  );
  if (missingTopics.length > 0) {
    suggestions.push(`Consider discussing: ${missingTopics.slice(0, 3).join(", ")}`);
  }
  suggestions.push("Use real-world examples to illustrate your points");
  if (overallScore < 70) suggestions.push("Practice structuring answers using the STAR method");

  if (strengths.length === 0) strengths.push("Attempted to answer the question");
  if (improvements.length === 0) improvements.push("Keep refining your communication skills");

  return { relevance, technicalAccuracy, communicationClarity, overallScore, strengths, improvements, suggestions };
}
