import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useNavigate, useParams } from "react-router-dom";
import { QUESTIONS_DB, ROLES, type InterviewQuestion, type InterviewResponse, type InterviewSession } from "@/data/questions";
import { evaluateAnswer } from "@/services/aiEvaluator";
import { Sparkles, Mic, MicOff, ArrowRight, Loader2, Send, ChevronLeft } from "lucide-react";

export default function Interview() {
  const { roleId } = useParams<{ roleId: string }>();
  const navigate = useNavigate();
  const role = ROLES.find((r) => r.id === roleId);
  const questions = QUESTIONS_DB.filter((q) => q.role === roleId);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [answer, setAnswer] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isEvaluating, setIsEvaluating] = useState(false);
  const [responses, setResponses] = useState<InterviewResponse[]>([]);
  const recognitionRef = useRef<any>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const currentQuestion = questions[currentIndex];
  const progress = ((currentIndex) / questions.length) * 100;

  useEffect(() => {
    if (!role || questions.length === 0) navigate("/dashboard");
  }, [role, questions, navigate]);

  const toggleRecording = () => {
    if (!("webkitSpeechRecognition" in window) && !("SpeechRecognition" in window)) {
      alert("Speech recognition not supported. Please use Chrome or Edge.");
      return;
    }

    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = "en-US";

    recognition.onresult = (event: any) => {
      let transcript = "";
      for (let i = 0; i < event.results.length; i++) {
        transcript += event.results[i][0].transcript;
      }
      setAnswer(transcript);
    };

    recognition.onerror = () => setIsRecording(false);
    recognition.onend = () => setIsRecording(false);

    recognitionRef.current = recognition;
    recognition.start();
    setIsRecording(true);
  };

  const handleSubmitAnswer = async () => {
    if (!answer.trim() || !currentQuestion) return;

    if (isRecording) {
      recognitionRef.current?.stop();
      setIsRecording(false);
    }

    setIsEvaluating(true);
    const feedback = await evaluateAnswer(currentQuestion, answer);
    const response: InterviewResponse = { questionId: currentQuestion.id, answer, score: feedback.overallScore, feedback };
    const newResponses = [...responses, response];
    setResponses(newResponses);
    setIsEvaluating(false);

    if (currentIndex < questions.length - 1) {
      setCurrentIndex((i) => i + 1);
      setAnswer("");
    } else {
      // Save session
      const session: InterviewSession = {
        id: Date.now().toString(),
        role: roleId!,
        date: new Date().toISOString(),
        responses: newResponses,
        averageScore: Math.round(newResponses.reduce((a, r) => a + r.score, 0) / newResponses.length),
        status: "completed",
      };
      const existing = JSON.parse(localStorage.getItem("interview_history") || "[]");
      localStorage.setItem("interview_history", JSON.stringify([session, ...existing]));
      navigate(`/results/${session.id}`);
    }
  };

  if (!currentQuestion) return null;

  return (
    <div className="min-h-screen bg-gradient-surface">
      <nav className="sticky top-0 z-50 glass">
        <div className="container mx-auto flex items-center justify-between h-16 px-6">
          <Button variant="ghost" onClick={() => navigate("/dashboard")}>
            <ChevronLeft className="w-4 h-4" /> Dashboard
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-display font-bold">{role?.label} Interview</span>
          </div>
          <span className="text-sm text-muted-foreground font-medium">
            {currentIndex + 1} / {questions.length}
          </span>
        </div>
      </nav>

      {/* Progress bar */}
      <div className="h-1 bg-secondary">
        <motion.div className="h-full bg-gradient-primary" animate={{ width: `${progress}%` }} transition={{ duration: 0.3 }} />
      </div>

      <div className="container mx-auto px-6 py-10 max-w-3xl">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -30 }}
            transition={{ duration: 0.3 }}
          >
            {/* Question */}
            <div className="mb-8">
              <div className="flex items-center gap-2 mb-4">
                <span className={`px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary`}>
                  {currentQuestion.category}
                </span>
                <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                  currentQuestion.difficulty === "easy" ? "bg-success/10 text-success" :
                  currentQuestion.difficulty === "medium" ? "bg-warning/10 text-warning" :
                  "bg-destructive/10 text-destructive"
                }`}>
                  {currentQuestion.difficulty}
                </span>
              </div>
              <h2 className="text-2xl md:text-3xl font-display font-bold leading-snug">
                {currentQuestion.question}
              </h2>
            </div>

            {/* Answer area */}
            <div className="space-y-4">
              <div className="relative">
                <textarea
                  ref={textareaRef}
                  value={answer}
                  onChange={(e) => setAnswer(e.target.value)}
                  placeholder="Type your answer here or click the microphone to speak..."
                  className="w-full min-h-[200px] p-5 rounded-2xl bg-card border border-border text-foreground font-body resize-none focus:outline-none focus:ring-2 focus:ring-ring transition-shadow"
                  disabled={isEvaluating}
                />
                {isRecording && (
                  <div className="absolute top-4 right-4 flex items-center gap-2">
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-destructive opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-destructive"></span>
                    </span>
                    <span className="text-xs text-destructive font-medium">Recording</span>
                  </div>
                )}
              </div>

              <div className="flex items-center gap-3">
                <Button
                  variant={isRecording ? "destructive" : "outline"}
                  size="lg"
                  onClick={toggleRecording}
                  disabled={isEvaluating}
                  className="gap-2"
                >
                  {isRecording ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                  {isRecording ? "Stop Recording" : "Start Speaking"}
                </Button>

                <Button
                  variant="hero"
                  size="lg"
                  onClick={handleSubmitAnswer}
                  disabled={!answer.trim() || isEvaluating}
                  className="flex-1 gap-2"
                >
                  {isEvaluating ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" /> Analyzing with AI...
                    </>
                  ) : currentIndex < questions.length - 1 ? (
                    <>
                      Submit & Next <ArrowRight className="w-5 h-5" />
                    </>
                  ) : (
                    <>
                      Submit & Finish <Send className="w-5 h-5" />
                    </>
                  )}
                </Button>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>
    </div>
  );
}
