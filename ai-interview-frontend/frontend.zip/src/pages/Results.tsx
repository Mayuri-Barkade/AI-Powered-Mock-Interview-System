import { useEffect, useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { useNavigate, useParams } from "react-router-dom";
import { QUESTIONS_DB, ROLES, type InterviewSession } from "@/data/questions";
import { Sparkles, ArrowLeft, Trophy, Target, MessageSquare, Lightbulb, CheckCircle2, AlertCircle, ChevronDown, ChevronUp } from "lucide-react";

function ScoreRing({ score, size = 120, label }: { score: number; size?: number; label: string }) {
  const radius = (size - 12) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  const color = score >= 80 ? "hsl(var(--success))" : score >= 60 ? "hsl(var(--warning))" : "hsl(var(--destructive))";

  return (
    <div className="flex flex-col items-center gap-2">
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="hsl(var(--border))" strokeWidth="8" />
        <motion.circle
          cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={color} strokeWidth="8"
          strokeLinecap="round" strokeDasharray={circumference}
          initial={{ strokeDashoffset: circumference }}
          animate={{ strokeDashoffset: offset }}
          transition={{ duration: 1, delay: 0.3 }}
        />
      </svg>
      <div className="absolute flex flex-col items-center justify-center" style={{ width: size, height: size }}>
        <span className="text-2xl font-display font-bold">{score}%</span>
      </div>
      <span className="text-sm text-muted-foreground font-medium">{label}</span>
    </div>
  );
}

export default function Results() {
  const { sessionId } = useParams<{ sessionId: string }>();
  const navigate = useNavigate();
  const [session, setSession] = useState<InterviewSession | null>(null);
  const [expandedQ, setExpandedQ] = useState<number | null>(0);

  useEffect(() => {
    const history: InterviewSession[] = JSON.parse(localStorage.getItem("interview_history") || "[]");
    const found = history.find((s) => s.id === sessionId);
    if (found) setSession(found);
    else navigate("/dashboard");
  }, [sessionId, navigate]);

  if (!session) return null;

  const role = ROLES.find((r) => r.id === session.role);
  const avgRelevance = Math.round(session.responses.reduce((a, r) => a + r.feedback.relevance, 0) / session.responses.length);
  const avgTechnical = Math.round(session.responses.reduce((a, r) => a + r.feedback.technicalAccuracy, 0) / session.responses.length);
  const avgClarity = Math.round(session.responses.reduce((a, r) => a + r.feedback.communicationClarity, 0) / session.responses.length);

  return (
    <div className="min-h-screen bg-gradient-surface">
      <nav className="sticky top-0 z-50 glass">
        <div className="container mx-auto flex items-center justify-between h-16 px-6">
          <Button variant="ghost" onClick={() => navigate("/dashboard")}>
            <ArrowLeft className="w-4 h-4" /> Dashboard
          </Button>
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-primary flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-primary-foreground" />
            </div>
            <span className="font-display font-bold">Results</span>
          </div>
          <div />
        </div>
      </nav>

      <div className="container mx-auto px-6 py-10 max-w-4xl">
        {/* Header */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center mb-12">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-success/10 text-success text-sm font-medium mb-4">
            <Trophy className="w-4 h-4" /> Interview Complete
          </div>
          <h1 className="text-3xl md:text-4xl font-display font-bold mb-2">{role?.label} Interview Results</h1>
          <p className="text-muted-foreground">Here's how you performed across all questions</p>
        </motion.div>

        {/* Score Cards */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-12">
          {[
            { score: session.averageScore, label: "Overall", icon: Trophy },
            { score: avgRelevance, label: "Relevance", icon: Target },
            { score: avgTechnical, label: "Technical", icon: Lightbulb },
            { score: avgClarity, label: "Clarity", icon: MessageSquare },
          ].map((item, i) => (
            <div key={i} className="relative p-6 rounded-2xl bg-card border border-border flex flex-col items-center">
              <ScoreRing score={item.score} size={100} label={item.label} />
            </div>
          ))}
        </motion.div>

        {/* Per-question Breakdown */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.2 }}>
          <h2 className="text-xl font-display font-semibold mb-6">Question Breakdown</h2>
          <div className="space-y-3">
            {session.responses.map((resp, i) => {
              const q = QUESTIONS_DB.find((x) => x.id === resp.questionId);
              const isExpanded = expandedQ === i;
              return (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.25 + i * 0.05 }}
                  className="rounded-2xl bg-card border border-border overflow-hidden"
                >
                  <button
                    onClick={() => setExpandedQ(isExpanded ? null : i)}
                    className="w-full flex items-center justify-between p-5 text-left hover:bg-secondary/50 transition-colors"
                  >
                    <div className="flex items-center gap-3 flex-1 min-w-0">
                      <span className={`flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center font-display font-bold text-sm ${
                        resp.score >= 80 ? "bg-success/10 text-success" :
                        resp.score >= 60 ? "bg-warning/10 text-warning" :
                        "bg-destructive/10 text-destructive"
                      }`}>
                        {resp.score}
                      </span>
                      <span className="font-medium truncate">{q?.question}</span>
                    </div>
                    {isExpanded ? <ChevronUp className="w-5 h-5 text-muted-foreground flex-shrink-0" /> : <ChevronDown className="w-5 h-5 text-muted-foreground flex-shrink-0" />}
                  </button>
                  {isExpanded && (
                    <motion.div initial={{ height: 0 }} animate={{ height: "auto" }} className="border-t border-border">
                      <div className="p-5 space-y-5">
                        <div>
                          <h4 className="text-sm font-medium text-muted-foreground mb-2">Your Answer</h4>
                          <p className="text-sm bg-secondary/50 rounded-xl p-4">{resp.answer}</p>
                        </div>
                        <div className="grid grid-cols-3 gap-3">
                          {[
                            { label: "Relevance", value: resp.feedback.relevance },
                            { label: "Technical", value: resp.feedback.technicalAccuracy },
                            { label: "Clarity", value: resp.feedback.communicationClarity },
                          ].map((m, j) => (
                            <div key={j} className="p-3 rounded-xl bg-secondary/50 text-center">
                              <div className="text-lg font-display font-bold">{m.value}%</div>
                              <div className="text-xs text-muted-foreground">{m.label}</div>
                            </div>
                          ))}
                        </div>
                        <div className="grid md:grid-cols-2 gap-4">
                          <div>
                            <h4 className="text-sm font-medium flex items-center gap-1.5 mb-2">
                              <CheckCircle2 className="w-4 h-4 text-success" /> Strengths
                            </h4>
                            <ul className="space-y-1">
                              {resp.feedback.strengths.map((s, k) => (
                                <li key={k} className="text-sm text-muted-foreground">• {s}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <h4 className="text-sm font-medium flex items-center gap-1.5 mb-2">
                              <AlertCircle className="w-4 h-4 text-warning" /> Improvements
                            </h4>
                            <ul className="space-y-1">
                              {resp.feedback.improvements.map((s, k) => (
                                <li key={k} className="text-sm text-muted-foreground">• {s}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                        {resp.feedback.suggestions.length > 0 && (
                          <div>
                            <h4 className="text-sm font-medium flex items-center gap-1.5 mb-2">
                              <Lightbulb className="w-4 h-4 text-info" /> Suggestions
                            </h4>
                            <ul className="space-y-1">
                              {resp.feedback.suggestions.map((s, k) => (
                                <li key={k} className="text-sm text-muted-foreground">• {s}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Actions */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="flex flex-col sm:flex-row gap-4 mt-10 justify-center">
          <Button variant="hero" size="lg" onClick={() => navigate(`/interview/${session.role}`)}>
            Retry This Role
          </Button>
          <Button variant="outline" size="lg" onClick={() => navigate("/dashboard")}>
            Choose Another Role
          </Button>
          <Button variant="ghost" size="lg" onClick={() => navigate("/history")}>
            View History
          </Button>
        </motion.div>
      </div>
    </div>
  );
}
